window.env = {
  SUPABASE_URL: "https://qpnjabqpixpzmoyxpqff.supabase.co",
  SUPABASE_ANON_KEY: "your-real-anon-key-here"
}
